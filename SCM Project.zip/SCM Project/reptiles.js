function croco() {
    
    document.getElementById("name1").innerHTML="<b>CROCODILE</b>";

}
function turtle() {

    document.getElementById("name2").innerHTML="<b>TURTLE</b>";

}
function chameleon() {

    document.getElementById("name3").innerHTML="<b>CHAMELEON</b>";

}
function snake() {

    document.getElementById("name4").innerHTML="<b>SNAKE</b>";

}
function lizard() {

    document.getElementById("name5").innerHTML="<b>LIZARD</b>";


}
function alligator() {

    document.getElementById("name6").innerHTML="<b>ALLIGATOR</b>";

}
function tortoise() {

    document.getElementById("name7").innerHTML="<b>TORTOISE</b>";

}
function tuatara() {

    document.getElementById("name8").innerHTML="<b>TUATARA</b>";

}
function gecko(){

    document.getElementById("name9").innerHTML="<b>GECKO</b>";
    
}